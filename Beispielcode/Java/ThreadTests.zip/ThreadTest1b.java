/* ThreadTest1b.java
 Version 1.1
 Autor: M. Hübner
 Zweck: Beispiel für das Starten von mehreren Threads 
 mit Threaderzeugung über Runnable-Interface
 */

public class ThreadTest1b {
  /* Beispiel für das Starten von mehreren Threads */
  
  public final int maximum = 200;  // Maximaler Zählerstand bis zum Abbruch

  public static void main(String[] args) {
    /* Main: wird vom Hauptthread ausgeführt */

    (new ThreadTest1b()).performThreadTest();
    System.err.println("-- Hauptthread wird beendet!--");
  }
  
  public void performThreadTest() {
    /* Erzeuge Thread-Objekte (nur Java-Objekte) */
    Thread threadZahl = new Thread(new MyRunnableZahl("Runnable Zahl", this));
    Thread threadText = new Thread(new MyRunnableText("Runnable Text", this));
    System.err.println("-- Noch nichts passiert!--");

    /* Starte Threads */
    threadZahl.start();
    threadText.start();
  }
}

/* Eigene Klasse */
class MyRunnableZahl implements Runnable {
	private String myName;
   private ThreadTest1b caller;
	
	public MyRunnableZahl(String myName, ThreadTest1b caller) {
      this.myName = myName;
      this.caller = caller;
   }
   
  /* Hochzählen und Zahlen ausgeben */
  public void run() {
    for (int i = 0; i < caller.maximum; i++) {
      System.err.println(myName + ": " + i);
    }
  }
}

/* Eigene Klasse */
class MyRunnableText implements Runnable {
	private String myName;
   private ThreadTest1b caller; 
	
	public MyRunnableText(String myName, ThreadTest1b caller) {
      this.myName = myName;
      this.caller = caller;      
   }
   	
  /* Intelligenten Text ausgeben */
  public void run() {
    for (int i = 0; i < caller.maximum; i++) {
      System.err.println(myName + ": ------------ Ich bin auch noch da! ");
    }
  }
}
