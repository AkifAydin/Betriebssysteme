/* ThreadTest4a.java
 Version 1.0
 Autor: M. H�bner
 Zweck: Beispiel f�r die sinnvolle Verwendung des Interrupt-Flags
 mit Abfangen der Interrupted-Exception
 */

public class ThreadTest4a {
  public static void main(String[] args) {
    MyThread4a testThread = new MyThread4a();
    testThread.start();
    try {
      /* F�r 2012,8 ms anhalten */
      Thread.sleep(2012, 800);      
    } catch (InterruptedException e) {
      // nichts
    }
    /* Thread unterbrechen (Interrupt-Flag setzen --> Interrupted-Exception) */
    testThread.interrupt();
    System.err.println("Es wurde gestoppt!");
  }
}

class MyThread4a extends Thread {
  /* Hochz�hlen und Zahlen ausgeben */
  public void run() {
    int i = 0;

	/* try/catch ausserhalb der while-Schleife! */
	try {
		while (!isInterrupted()) { 	    
			System.err.println(i++);
	      /* F�r 100 ms anhalten */
	      Thread.sleep(100);
		}
	} catch (InterruptedException e) {
	  System.err.println("MyThread4a wurde durch Interrupt geweckt!");
   }
   System.err.println("MyThread4a wird beendet!");
  }
}
