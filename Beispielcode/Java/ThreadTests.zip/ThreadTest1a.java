/* ThreadTest1a.java
 Version 1.1
 Autor: M. Hübner
 Zweck: Beispiel für das Starten von mehreren Threads
 mit Threaderzeugung über Ableitung aus der Thread-Klasse
 */

public class ThreadTest1a {
  /* Beispiel für das Starten von mehreren Threads */
  
  public final int maximum = 200;  // Maximaler Zählerstand bis zum Abbruch

  public static void main(String[] args) {
    /* Main: wird vom Hauptthread ausgeführt */

    (new ThreadTest1a()).performThreadTest();
    System.err.println("-- Hauptthread wird beendet!--");
  }
  
  public void performThreadTest() {
    /* Erzeuge Thread-Objekte (nur Java-Objekte) */
    MyThreadZahl threadZahl = new MyThreadZahl("Zahlthread", this);
    MyThreadText threadText = new MyThreadText("Textthread", this);
    System.err.println("-- Noch nichts passiert!--");

    /* Starte Threads */
    threadZahl.start();
    threadText.start();
  }
}

/* Eigene Klasse */
class MyThreadZahl extends Thread {
	private String myName;
   private ThreadTest1a caller;
	
	public MyThreadZahl(String myName, ThreadTest1a caller) {
      this.myName = myName;
      this.caller = caller;
   }
   
  /* Hochzählen und Zahlen ausgeben */
  public void run() {
    for (int i = 0; i < caller.maximum; i++) {
      System.err.println(myName + ": " + i);
    }
  }
}

/* Eigene Klasse */
class MyThreadText extends Thread {
	private String myName;
   private ThreadTest1a caller; 
	
	public MyThreadText(String myName, ThreadTest1a caller) {
      this.myName = myName;
      this.caller = caller;      
   }
   	
  /* Intelligenten Text ausgeben */
  public void run() {
    for (int i = 0; i < caller.maximum; i++) {
      System.err.println(myName + ": ------------ Ich bin auch noch da! ");
    }
  }
}
