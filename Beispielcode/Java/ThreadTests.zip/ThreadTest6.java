import javax.swing.JOptionPane;

/* ThreadTest6.java
 Version 1.0
 Autor: M. Hübner
 Zweck: Beispiel für die Verwendung der setPriority-Methode
 */


public class ThreadTest6 {
  /* Beispiel für die Verwendung der setPriority-Methode */
  public static void main(String[] args) {
 
    /* Ausführung pausieren */
    JOptionPane
         .showMessageDialog(
               null,
               "Unter Windows: Bitte ggf. im Task-Manager jetzt die zu verwendenden CPUs auswaehlen (Strg-Alt-Entf - Details - Rechtsklick: Zugehoerigkeit festlegen)!",
               "Hinweis", JOptionPane.INFORMATION_MESSAGE);
     
    MyThread6a thread_A = new MyThread6a();
    MyThread6b thread_B = new MyThread6b();
    System.err.println("-- Noch nichts passiert!--");

    /* Priorität des main-Threads auf Maximum setzen */
    Thread.currentThread().setPriority(Thread.MAX_PRIORITY);

    /* Priorität thread_A nahezu auf Maximum setzen */
    thread_A.setPriority(Thread.NORM_PRIORITY + 2);

    /* Priorität thread_B auf Minimum setzen */
    thread_B.setPriority(Thread.MIN_PRIORITY);
    
    /* Threads starten */
    thread_B.start();
    thread_A.start();
    
    try {
      /* Main-Thread für mehrere Sekunden anhalten */
      Thread.sleep(5000);
    } catch (InterruptedException e) {
      // nichts
    }

    /* Threads beenden */
    thread_A.interrupt();
    thread_B.interrupt();
  }
}

class MyThread6a extends Thread {
  /* Hochzählen und Zahlen ausgeben */
  public void run() {
    int i = 0;
    /* Interrupt-Flag abfragen */
    while (!isInterrupted()) {
      System.err.println("Thread_A: " + i);
      i++;
    }
    System.err.println("Thread_A meldet sich bei Zaehlerstand " + i + " ab! Meine Prioritaet war: " + this.getPriority());
  }
}

class MyThread6b extends Thread {
  /* Intelligenten Text ausgeben */
  public void run() {
    int i = 0;
    /* Interrupt-Flag abfragen */
    while (!isInterrupted()) {
      System.err.println("--------------------------- Thread_B: " + i);
      i++;      
    }
    System.err.println("Thread_B meldet sich bei Zaehlerstand " + i + "  ab! Meine Prioritaet war: " + this.getPriority());    
  }
}
