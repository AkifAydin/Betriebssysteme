/* ThreadTest7a.java
 Version 1.0
 Autor: M. Hübner
 Zweck: Negativ-Beispiel für den Verzicht auf Synchronisation
 */


public class ThreadTest7a {
   /*
    * Beispiel fuer die Verwendung des Semaphor-Mechanismus zum wechselseitigen
    * Ausschluss
    */
   public static void main(String[] args) {
      OutputServer7 outputServer = new OutputServer7();

      MyThread7a threadZahl = new MyThread7a(outputServer);
      threadZahl.setName("Zahl-Thread");

      MyThread7b threadText = new MyThread7b(outputServer);
      threadText.setName("Hallo-Thread");

      outputServer.showOutput("-- Noch nichts passiert!--");


      threadZahl.start();
      threadText.start();

      try {
         /* Main-Thread anhalten */
         Thread.sleep(3000);
      } catch (InterruptedException e) {
         // nichts
      }

      /* Threads beenden */
      threadZahl.interrupt();
      threadText.interrupt();
   }
}

class OutputServer7 {

   public void showOutput(Object output) {
      /* Output ausgeben */
      /* 1. Ausgabenteil */
      showThreadName();

      try {
         /* Thread anhalten */
         Thread.sleep(10);
      } catch (InterruptedException e) {
         Thread.currentThread().interrupt();
      }

      /* 2. Ausgabenteil */
      System.err.println(output);
   }

   public void showThreadName() {
      /* Zeige aktuellen Threadnamen an */
      System.err.print("Output von " + Thread.currentThread().getName() + ": ");
   }
}

class MyThread7a extends Thread {
   /* Hochzaehlen und Zahlen ausgeben */
   private OutputServer7 outputServer;

   public MyThread7a(OutputServer7 outputServer) {
      this.outputServer = outputServer;
   }

   public void run() {
      int i = 0;
      /* Interrupt-Flag abfragen */
      while (!isInterrupted()) {
         outputServer.showOutput(i++);
      }
   }
}

class MyThread7b extends Thread {
   /* Intelligenten Text ausgeben */

   private OutputServer7 outputServer;

   public MyThread7b(OutputServer7 outputServer) {
      this.outputServer = outputServer;
   }

   public void run() {
      /* Interrupt-Flag abfragen */
      while (!isInterrupted()) {
         outputServer.showOutput("------------ Hallo! --------------");
      }
   }
}
